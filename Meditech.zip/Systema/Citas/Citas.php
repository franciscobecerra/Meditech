


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    
    <title>MediTech</title>
    <link rel="stylesheet" type="text/css" href="/Systema/footerSystema.css">
    <link rel="stylesheet" type="text/css" href="/Systema/Cuenta/Cuenta.css">
        
    
</head>
<body>
    <header>
        <div id=Botones>

    	    <ul class=nav>

				<li> <button id="SingUP" onclick="menu(1)" > Cerrar sesión </button> </li>
				<li> <button onclick="menu(2)" > Mi cuenta </button> </li>
                <li> <button onclick="menu(3)" > Citas </button> </li>
                <li> <button onclick="menu(4)" > Recetas </button> </li>
                <li> <button onclick="menu(5)" > Doctores </button> </li>
						
            </ul>
        </div>
        <H1 id=titulo> MediTech </H1>
    </header>
    
    <div class="contenido" id="contenido"> </div>
    
</body>
</html>
   
   