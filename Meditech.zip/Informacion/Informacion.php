<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Meditech</title>
</head>
<body>
   
   <h1>Informacion</h1>
    
</body>
</html>